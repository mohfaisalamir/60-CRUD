package com.enigma.Soal1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Soal1Application {

	public static void main(String[] args) {
		SpringApplication.run(Soal1Application.class, args);
	}

}
